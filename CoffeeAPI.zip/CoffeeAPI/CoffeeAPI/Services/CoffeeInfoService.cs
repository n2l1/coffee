﻿using CoffeeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Services
{
    public class CoffeeService
    {
        public List<CoffeeInfo> GetCoffeeTypes()
        {
            List<CoffeeInfo> coffeeTypes = new List<CoffeeInfo>
            {
                new CoffeeInfo { Name = "Americano", Price = 2.0, Points = (decimal) 2 / 100 },
                new CoffeeInfo { Name = "Cappaccino", Price = 2.0, Points = (decimal) 2 / 100  },
                new CoffeeInfo { Name = "Espresso", Price = 3.5, Points = (decimal) 3.5 / 100 },
                new CoffeeInfo { Name = "Latte", Price = 2.0, Points = (decimal) 2 / 100 },
                new CoffeeInfo { Name = "Macchiato", Price = 4, Points = (decimal) 4 / 100 },                
            };

            return coffeeTypes;
        }
    }



}
