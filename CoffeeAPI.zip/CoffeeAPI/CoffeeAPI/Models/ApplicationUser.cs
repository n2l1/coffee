﻿using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{
    // public class ApplicationUser : IdentityUser { }
    public class ApplicationUser : IdentityUser
    {
        public string Password { get; set; }
    }
}