﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{
    public class AuthRequest: IdentityUser
    {
        public AuthRequest()
        {
            LockoutEnabled = false;
            PhoneNumberConfirmed = false;
            TwoFactorEnabled = false;
        }

        [BindProperty(Name = "email")]
        public override string Email { get; set; }

        [BindProperty(Name = "phone")]

        public string Phone { get; set; }
    }
}
