﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{
    public class CoffeeProduct : QuantityBought
    {
        private decimal _point;

        public int CoffeeId { get; set; }
        public string CoffeeName { get; set; }
        public decimal CoffeePrice { get; set; }
        public decimal Point
        {
            get { return _point; }
            set { _point = Decimal.Round(value, 3); }
        }
    }
}
