﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int CoffeeId { get; set; }
        public int Quantity { get; set; }

        public Order oOrder { get; set; }
        public List<CoffeeProduct> pProducts { get; set; }
    }
}
