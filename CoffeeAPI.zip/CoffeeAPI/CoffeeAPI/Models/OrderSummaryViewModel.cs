﻿using System;

namespace CoffeeAPI.Models
{
    public class OrderSummaryViewModel
    {
        private decimal _totalPointsEarned;
        private decimal _currentPointsBalance;
        public string Username { get; set; }
        public decimal TotalCost { get; set; }
        public decimal TotalPointsEarned
        {
            get { return _totalPointsEarned; }
            set { _totalPointsEarned = Decimal.Round(value, 3); }
        }
        public decimal CurrentPointsBalance
        {
            get { return _currentPointsBalance; }
            set { _currentPointsBalance = Decimal.Round(value, 3); }
        }
    }
}