﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{
    public class CoffeeInfo
    {
        private decimal _points;
        public string Name { get; set; }
        public double Price { get; set; }
        public decimal Points
        {
            get { return _points; }
            set { _points = Decimal.Round(value, 3); }
        }
    }
}
