﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeAPI.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public string UserEmail { get; set; }

        public List<OrderItem> OrderItems { get; set; }
        
        [Column(TypeName = "datetime2")]
        public DateTime OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
    }
}