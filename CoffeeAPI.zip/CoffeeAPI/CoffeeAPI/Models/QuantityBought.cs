﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{
    public class QuantityBought
    {
        public int Qty { get; set; }
    }
}
