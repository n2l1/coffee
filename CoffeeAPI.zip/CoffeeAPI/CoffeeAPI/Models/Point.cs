﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Models
{

    public class Point
    {
        private decimal _pointsEarned;
        private decimal _pointsRedeemed;
        private decimal _pointsBalance;
        public int PointId { get; set; }
        public decimal PointsEarned
        {
            get { return _pointsEarned; }
            set { _pointsEarned = Decimal.Round(value, 3); }
        }
        public decimal PointsRedeemed
        {
            get { return _pointsRedeemed; }
            set { _pointsRedeemed = Decimal.Round(value, 3); }
        }
        public decimal PointsBalance
        {
            get { return _pointsBalance; }
            set { _pointsBalance = Decimal.Round(value, 3); }
        }

        public string UserEmail { get; set; }
        public ApplicationUser User { get; set; }
    }
}
