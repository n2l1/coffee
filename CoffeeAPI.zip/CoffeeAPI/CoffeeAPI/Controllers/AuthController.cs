﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Threading.Tasks;
using CoffeeAPI.Data;
using CoffeeAPI.Models;
using CoffeeAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace CoffeeAPI.Controllers
{
    [ApiController]
    
    public class AuthController : Controller
    {
        private readonly IConfiguration _config;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly CoffeeAPIDbContext _coffeeAPIDbContext;
        public AuthController(IConfiguration config, UserManager<ApplicationUser> userManager, 
            SignInManager<ApplicationUser> signInManager, CoffeeAPIDbContext coffeeAPIDbContext) 
        {
            _config = config;
            _userManager = userManager;
            _signInManager = signInManager;
            _coffeeAPIDbContext = coffeeAPIDbContext;
        }

        [HttpGet]
        [Route("Auth/Login")]
        public IActionResult Login()
        {
            return View();
        }

        private void CreateJWToken(ApplicationUser authUser)
        {
            GenerateJwtToken generateJwtToken = new GenerateJwtToken(_config, authUser);
            var _token = generateJwtToken.ReturnJWTSecurityToken();

            // save the JWT token in a cookie
            var cookieOptions = new CookieOptions
            {
                Expires = DateTime.Now.AddDays(1),
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict
            };
            Response.Cookies.Append("jwtCoffee187", new JwtSecurityTokenHandler().WriteToken(_token), cookieOptions);
        } 


        [Route("api/[controller]/Login")]
        [HttpPost]
        [Route("Login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromForm] ApplicationUser authenticationRequest)
        {

            var user = await _userManager.FindByEmailAsync(authenticationRequest.UserName);

            if (user == null)
            {
                // The user does not exist, redirect to register screen
                return View("Register");
            }

            var result = await _signInManager.PasswordSignInAsync(user.UserName, authenticationRequest.Password, false, false);

            var customer = _coffeeAPIDbContext.ApplicationUsers.FirstOrDefaultAsync(u => u.Email == authenticationRequest.Email);
            if (customer is null)
            {
                // redirect User to Registration logic
                return RedirectToAction("Register", "Auth");
            }
            else
            {
                // create a json web token and redirect
                CreateJWToken(authenticationRequest);
            }
            return RedirectToAction("ProductList", "Products");
        }

        [HttpGet]
        [Route("Auth/Register")]
        [AllowAnonymous]
        public IActionResult Register()
        {
            return View();
        }

        [Route("api/Auth/Register")]  
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] Customer model)
        {
            var _user = new ApplicationUser { UserName = model.Email, Email = model.Email };
            var result = await _userManager.CreateAsync(_user, model.Password);

            if (!result.Succeeded)
            {
                return BadRequest(result.Errors);
            }

            var customer = _coffeeAPIDbContext.ApplicationUsers.FirstOrDefaultAsync(u => u.Email == _user.Email);
            if (customer is null)
            {
                // redirect User to Registration logic
                return RedirectToAction("Register", "Auth");
            }
            else
            {
                // create a json web token and redirect
                CreateJWToken(_user);
            }
            return RedirectToAction("ProductList", "Products");
        }
    }
}
