﻿using CoffeeAPI.Data;
using CoffeeAPI.Models;
using CoffeeAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;

namespace CoffeeAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : Controller
    {
        private readonly IConfiguration _config;
        private readonly CoffeeAPIDbContext _coffeeAPIDbContext;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public ProductsController(IConfiguration configuration, CoffeeAPIDbContext coffeeAPIDbContext, 
            UserManager<ApplicationUser> userManager,
            IHttpContextAccessor httpContextAccessor)
        {
            _config = configuration;
            _coffeeAPIDbContext = coffeeAPIDbContext;
            _userManager = userManager;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return View();
        }

        [HttpGet]
        [Route("ProductList")]
        public IActionResult ProductList()
        {
            ApplicationUser applicationUser = GetApplicationUserFromToken();

            // Create new JWT token with new expiration time and save it in the cookie
            GenerateJwtToken generateJwtToken = new GenerateJwtToken(_config, applicationUser);
            var cookieOptions = new CookieOptions
            {
                Expires = DateTime.Now.AddDays(1),
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict
            };
            var newJwtToken = generateJwtToken.GenerateToken(applicationUser);
            HttpContext.Response.Cookies.Append("jwtCoffee187", newJwtToken, cookieOptions);

            var user = _httpContextAccessor.HttpContext.User.Identity.Name;
            ViewBag.User = user;

            // Return view displaying list of coffees
            CoffeeService coffeeService = new CoffeeService();
            return View("Product", coffeeService.GetCoffeeTypes());
        }

        private ApplicationUser GetApplicationUserFromToken()
        {
            // Retrieve JWT token from the cookie
            var jwtToken = HttpContext.Request.Cookies["jwtCoffee187"];

            // Verify JWT token to ensure that user is authenticated
            var handler = new JwtSecurityTokenHandler();
            var token = handler.ReadJwtToken(jwtToken);

            var applicationUser = new ApplicationUser()
            {
                Email = token.Payload.First().Value.ToString(),
                UserName = token.Payload.First().Value.ToString()
            };
            return applicationUser;
        }

        [HttpPost]
        [Route("ProductList")]
        public async Task<IActionResult> ProductList(OrderItem items)
        {
            ApplicationUser applicationUser = GetApplicationUserFromToken();

            var customer = await _coffeeAPIDbContext.ApplicationUsers.FirstOrDefaultAsync(u => u.Email == applicationUser.Email);
            Point point = new Point();
            if (_coffeeAPIDbContext.Point.ToList().Where(a => a.UserEmail == applicationUser.Email).ToList().Count() > 0)            if (_coffeeAPIDbContext.Point.ToList().Count() > 0)
            {
                point = _coffeeAPIDbContext.Point
                            .OrderByDescending(p => p.PointId)
                            .FirstOrDefault(p => p.UserEmail == applicationUser.Email);
            }

            decimal currentPoints = point.PointsBalance;
            Point createPoint = null;
            Order createdOrder = null;
            OrderItem orderItem = null;

            using (TransactionScope scope = new TransactionScope())
            {
                try
                {
                    // Add/update the customer's points balance
                    createPoint = CreatePoint(items, currentPoints);

                    // Add the Order
                    createdOrder = CreateOrder(items.oOrder);

                    items.oOrder.OrderId = createdOrder.OrderId;

                    // Add OrderItem
                    orderItem = CreateOrderItem(items);

                    scope.Complete();
                }
                catch (Exception ex)
                {
                    scope.Dispose();
                }
            }

            // Return a view showing the order summary
            var result = new
            {
                Username = $"{customer.Email} ",
                TotalCost = createdOrder.TotalAmount,
                TotalPointsEarned = createPoint.PointsEarned,
                CurrentPointsBalance = createPoint.PointsBalance
            };
            return Json(result);
        }

        private Point CreatePoint(OrderItem _orderItem, decimal currentPoints)
        {
            decimal newPoints = 0;
            decimal totalPoints = 0;
            Point point = new Point();
            CoffeeService coffeeService = new CoffeeService();
            List<CoffeeInfo> allcoffeeTypes = new List<CoffeeInfo>();

            _orderItem.pProducts.ForEach(x => { newPoints += x.Point; });
            totalPoints =+ newPoints;

            var boughtCoffees = new List<CoffeeInfo>();
            allcoffeeTypes = coffeeService.GetCoffeeTypes();
            foreach (var coffeeProduct in _orderItem.pProducts)
            {
                foreach (var knownCoffee in allcoffeeTypes)
                {
                    if (coffeeProduct.CoffeeName == knownCoffee.Name)
                    {
                        boughtCoffees.Add(knownCoffee);
                        decimal pointsEarned = (decimal)(knownCoffee.Price / 100);
                        point.PointsEarned += (pointsEarned * coffeeProduct.Qty);
                    }
                }
            }

            point.PointsBalance = currentPoints + point.PointsEarned;
            point.UserEmail = _orderItem.oOrder.UserEmail;
            
            var _point = _coffeeAPIDbContext.Point.Add(point);
            _coffeeAPIDbContext.SaveChanges();
            return _point.Entity;
        }
        private OrderItem CreateOrderItem(OrderItem _orderItem)
        {
            OrderItem newOrderItem = null;
            _orderItem.pProducts.ForEach(productLine =>
            {
                int coffeeId = 0; 
                
                switch (productLine.CoffeeName)
                {
                    case "Americano":
                        coffeeId = (int)CoffeeType.Americano;                        
                        break;
                    case "Cappaccino":
                        coffeeId = (int)CoffeeType.Cappaccino;
                        break;
                    case "Espresso":
                        coffeeId = (int)CoffeeType.Espresso;
                        break;
                    case "Latte":
                        coffeeId = (int)CoffeeType.Latte;
                        break;
                    case "Macchiato":
                        coffeeId = (int)CoffeeType.Macchiato;
                        break;
                }
                
                newOrderItem = new OrderItem() { OrderId = _orderItem.oOrder.OrderId, CoffeeId = coffeeId, Quantity = productLine.Qty };
                var orderItem = _coffeeAPIDbContext.OrderItem.Add(newOrderItem);
            });
            _coffeeAPIDbContext.SaveChanges();
            return newOrderItem;
        }
        private Order CreateOrder(Order _order)
        {
            Order newOrder = new Order() { UserEmail = _order.UserEmail, OrderDate = DateTime.UtcNow, TotalAmount = _order.TotalAmount };
            var order = _coffeeAPIDbContext.Order.Add(newOrder);
            _coffeeAPIDbContext.SaveChanges();
            return order.Entity;
        }
    }
}
