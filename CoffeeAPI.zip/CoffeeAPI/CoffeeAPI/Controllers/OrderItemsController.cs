﻿using CoffeeAPI.Data;
using CoffeeAPI.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CoffeeAPI.Controllers
{
    [ApiController]
    public class OrderItemsController : Controller
    {

        private readonly CoffeeAPIDbContext _coffeeAPIDbContext;
        private readonly UserManager<ApplicationUser> _userManager;

        public OrderItemsController(CoffeeAPIDbContext coffeeAPIDbContext, UserManager<ApplicationUser> userManager)
        {
            _coffeeAPIDbContext = coffeeAPIDbContext;
            _userManager = userManager;
        }

        [Route("api/[controller]/Get")]
        [HttpGet]
        [Route("Get")]
        public IActionResult Get()
        {
            return View();
        }
    }
}
