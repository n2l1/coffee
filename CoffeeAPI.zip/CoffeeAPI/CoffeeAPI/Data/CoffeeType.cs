﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Data
{
    public enum CoffeeType
    {
        [Description("Americano")]
        Americano = 1,
        [Description("Cappaccino")]
        Cappaccino,
        [Description("Espresso")]
        Espresso,
        [Description("Latte")]
        Latte,
        [Description("Macchiato")]
        Macchiato
    }
}
