﻿using CoffeeAPI.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoffeeAPI.Data
{
    public class CoffeeAPIDbContext : IdentityDbContext<ApplicationUser>
    {
        public CoffeeAPIDbContext(DbContextOptions<CoffeeAPIDbContext> options)
            : base(options)
        { }
        

        public DbSet<AuthRequest> User { get; set; }
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
        public DbSet<Point> Point { get; set; }
        public DbSet<CoffeeProduct> CoffeeProduct { get; set; }
        public DbSet<Order> Order { get; set; }
        public DbSet<OrderItem> OrderItem { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ApplicationUser>().ToTable("AspNetUsers");

            modelBuilder.Entity<CoffeeProduct>(entity =>
            {
                entity.ToTable("CoffeeProduct");

                entity.HasKey(e => e.CoffeeId);

                entity.Property(e => e.CoffeeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CoffeePrice)
                    .HasColumnType("decimal(10, 0)");

                entity.Property(e => e.Point)
                    .IsRequired();
            });

            modelBuilder.Entity<OrderItem>(entity =>
            {
                entity.HasKey(e => e.OrderItemId);
                entity.Property(e => e.Quantity).IsRequired();

                entity.HasOne(e => e.oOrder)
                    .WithMany(o => o.OrderItems)
                    .HasForeignKey(e => e.OrderId);

                entity.ToTable("OrderItem");
            });

            modelBuilder.Entity<Point>(entity =>
            {
                entity.ToTable("Point");
                entity.Property(e => e.PointsBalance).IsRequired();
                entity.Property(e => e.PointsEarned).IsRequired();
                entity.Property(e => e.PointsRedeemed).IsRequired();
                entity.HasOne(e => e.User)
                    .WithMany()
                    .HasForeignKey(e => e.UserEmail);
            });


            //modelBuilder.Entity<Order>()
            //    .HasOne(p => p.User)
            //    .WithMany()
            //    .HasForeignKey(p => p.UserEmail);

            modelBuilder.Entity<Order>()
                .Property(o => o.TotalAmount)
                .HasColumnType("decimal(18,2)");


        }
    }
}
